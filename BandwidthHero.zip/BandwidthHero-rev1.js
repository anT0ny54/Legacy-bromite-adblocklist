// ==UserScript==
// @name         Bandwidth Hero Rev 1
// @namespace    bandwidth-hero-proxy-2
// @version      1.0.0
// @description  Bandwidth Hero image compression with quality, grayscale, maximum image width, lazy-image support, CSS backgrounds, CSP meta removal, and domain exclusions.
// @match        *://*/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    /*
     * Your Bandwidth Hero Proxy 2 endpoint.
     */
    const PROXY_URL =
        'https://YOUR-NETLIFY-SITE.netlify.app/api/index';

    /*
     * Domains excluded from processing.
     *
     * Subdomains are excluded automatically.
     */
    const EXCLUDED_DOMAINS = [
        'youtube.com',
        'google.com',
        'googleapis.com',
        'facebook.com',
        'instagram.com'
    ];

    /*
     * Bandwidth Hero settings.
     */
    const QUALITY = 40;
    const GRAYSCALE = 1;

    // 0 = WebP
    // 1 = JPEG
    const JPEG = 0;

    /*
     * Maximum output image width in pixels.
     *
     * 0 = disabled.
     *
     * This changes the downloaded image size through the proxy.
     * It is not only a CSS display limit.
     */
    const MAX_IMAGE_WIDTH = 1280;

    /*
     * Removes CSP and CSP report-only <meta> tags.
     *
     * This can remove HTML meta CSP declarations.
     * It cannot remove CSP headers sent by the server.
     */
    const STRIP_META_CSP = true;

    const LAZY_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset',
        'data-original',
        'data-original-src',
        'data-lazy',
        'data-image',
        'data-image-src',
        'data-url'
    ];

    const SOURCE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset'
    ];

    const OBSERVED_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset',
        'data-original',
        'data-original-src',
        'data-lazy',
        'data-image',
        'data-image-src',
        'data-url',
        'style',
        'class',
        'http-equiv'
    ];

    let proxyURLObject;

    try {
        proxyURLObject = new URL(PROXY_URL);
    } catch {
        console.error('[BH2] Invalid proxy URL:', PROXY_URL);
        return;
    }

    function normalizeDomain(domain) {
        return domain
            .toLowerCase()
            .trim()
            .replace(/^https?:\/\//, '')
            .replace(/^www\./, '')
            .split('/')[0]
            .split(':')[0];
    }

    const normalizedExcludedDomains =
        EXCLUDED_DOMAINS.map(normalizeDomain);

    function isExcludedDomain(hostname) {
        const currentHost = hostname
            .toLowerCase()
            .replace(/^www\./, '');

        return normalizedExcludedDomains.some(domain => {
            return (
                currentHost === domain ||
                currentHost.endsWith(`.${domain}`)
            );
        });
    }

    if (isExcludedDomain(location.hostname)) {
        console.info(
            '[BH2] Domain excluded:',
            location.hostname
        );

        return;
    }

    /*
     * Cache source URL -> proxy URL conversions.
     */
    const proxyURLCache = new Map();

    function isProxyURL(value) {
        if (!value || typeof value !== 'string') {
            return false;
        }

        try {
            const parsed = new URL(
                value,
                document.baseURI || location.href
            );

            return (
                parsed.origin === proxyURLObject.origin &&
                parsed.pathname === proxyURLObject.pathname
            );
        } catch {
            return false;
        }
    }

    function getAbsoluteURL(value) {
        if (!value || typeof value !== 'string') {
            return null;
        }

        value = value.trim();

        if (
            !value ||
            value.startsWith('data:') ||
            value.startsWith('blob:') ||
            value.startsWith('javascript:') ||
            value.startsWith('#') ||
            value.startsWith('about:')
        ) {
            return null;
        }

        try {
            return new URL(
                value,
                document.baseURI || location.href
            ).href;
        } catch {
            return null;
        }
    }

    function getProxyURL(originalURL) {
        const absoluteURL =
            getAbsoluteURL(originalURL);

        if (
            !absoluteURL ||
            isProxyURL(absoluteURL)
        ) {
            return null;
        }

        const cached =
            proxyURLCache.get(absoluteURL);

        if (cached) {
            return cached;
        }

        const proxy = new URL(PROXY_URL);

        proxy.searchParams.set(
            'url',
            absoluteURL
        );

        proxy.searchParams.set(
            'quality',
            String(QUALITY)
        );

        proxy.searchParams.set(
            'l',
            String(QUALITY)
        );

        proxy.searchParams.set(
            'bw',
            String(GRAYSCALE)
        );

        proxy.searchParams.set(
            'jpeg',
            String(JPEG)
        );

        if (
            Number.isFinite(MAX_IMAGE_WIDTH) &&
            MAX_IMAGE_WIDTH > 0
        ) {
            proxy.searchParams.set(
                'max_width',
                String(Math.floor(MAX_IMAGE_WIDTH))
            );
        }

        const result = proxy.href;

        proxyURLCache.set(
            absoluteURL,
            result
        );

        return result;
    }

    function rewriteSrcset(srcset) {
        if (!srcset) {
            return srcset;
        }

        let changed = false;

        const rewritten = srcset
            .split(',')
            .map(item => {
                const trimmed = item.trim();

                if (!trimmed) {
                    return item;
                }

                const parts = trimmed.split(/\s+/);
                const originalURL = parts.shift();
                const proxiedURL =
                    getProxyURL(originalURL);

                if (!proxiedURL) {
                    return trimmed;
                }

                changed = true;

                return [
                    proxiedURL,
                    ...parts
                ].join(' ');
            })
            .join(', ');

        return changed ? rewritten : srcset;
    }

    function rewriteCSSURLs(value) {
        if (!value || value === 'none') {
            return value;
        }

        return value.replace(
            /url\(\s*(['"]?)(.*?)\1\s*\)/gi,
            (match, quote, originalURL) => {
                const proxiedURL =
                    getProxyURL(originalURL);

                if (!proxiedURL) {
                    return match;
                }

                return `url("${proxiedURL}")`;
            }
        );
    }

    function getImageState(image) {
        let state = '';

        for (const attribute of LAZY_ATTRIBUTES) {
            state += `${attribute}:`;
            state += image.getAttribute(attribute) || '';
            state += '|';
        }

        return state;
    }

    function installImageErrorHandler(image) {
        if (
            image.dataset.bandwidthHeroErrorHandler
        ) {
            return;
        }

        image.dataset.bandwidthHeroErrorHandler =
            '1';

        image.addEventListener('error', () => {
            const originalURL =
                image.dataset.bandwidthHeroOriginal;

            if (
                originalURL &&
                !isProxyURL(originalURL)
            ) {
                console.warn(
                    '[BH2] Proxy failed; restoring original image'
                );

                image.src = originalURL;
            }
        });
    }

    function proxyImage(image) {
        if (!(image instanceof HTMLImageElement)) {
            return;
        }

        const state = getImageState(image);

        if (
            image.dataset.bandwidthHeroState === state
        ) {
            return;
        }

        image.dataset.bandwidthHeroState = state;

        for (const attribute of LAZY_ATTRIBUTES) {
            const value =
                image.getAttribute(attribute);

            if (!value) {
                continue;
            }

            if (attribute.includes('srcset')) {
                const rewritten =
                    rewriteSrcset(value);

                if (rewritten !== value) {
                    image.setAttribute(
                        attribute,
                        rewritten
                    );
                }

                continue;
            }

            const proxiedURL =
                getProxyURL(value);

            if (
                proxiedURL &&
                proxiedURL !== value
            ) {
                image.setAttribute(
                    attribute,
                    proxiedURL
                );
            }
        }

        const currentURL =
            image.getAttribute('src') ||
            image.currentSrc ||
            image.src;

        if (
            !currentURL ||
            isProxyURL(currentURL)
        ) {
            return;
        }

        const proxiedCurrentURL =
            getProxyURL(currentURL);

        if (!proxiedCurrentURL) {
            return;
        }

        if (
            !image.dataset.bandwidthHeroOriginal
        ) {
            image.dataset.bandwidthHeroOriginal =
                currentURL;
        }

        installImageErrorHandler(image);

        image.setAttribute(
            'src',
            proxiedCurrentURL
        );
    }

    function proxySource(source) {
        if (!(source instanceof HTMLSourceElement)) {
            return;
        }

        for (const attribute of SOURCE_ATTRIBUTES) {
            const value =
                source.getAttribute(attribute);

            if (!value) {
                continue;
            }

            if (attribute.includes('srcset')) {
                const rewritten =
                    rewriteSrcset(value);

                if (rewritten !== value) {
                    source.setAttribute(
                        attribute,
                        rewritten
                    );
                }

                continue;
            }

            const proxiedURL =
                getProxyURL(value);

            if (
                proxiedURL &&
                proxiedURL !== value
            ) {
                source.setAttribute(
                    attribute,
                    proxiedURL
                );
            }
        }
    }

    function proxyInputImage(input) {
        if (
            !(input instanceof HTMLInputElement) ||
            input.type !== 'image'
        ) {
            return;
        }

        const src = input.getAttribute('src');

        if (!src) {
            return;
        }

        const proxiedURL =
            getProxyURL(src);

        if (
            proxiedURL &&
            proxiedURL !== src
        ) {
            input.setAttribute(
                'src',
                proxiedURL
            );
        }
    }

    function proxyInlineBackground(element) {
        if (!(element instanceof HTMLElement)) {
            return;
        }

        const style =
            element.getAttribute('style');

        if (!style) {
            return;
        }

        const rewritten =
            rewriteCSSURLs(style);

        if (rewritten !== style) {
            element.setAttribute(
                'style',
                rewritten
            );
        }
    }

    function isCSPMeta(element) {
        if (!(element instanceof HTMLMetaElement)) {
            return false;
        }

        const httpEquiv =
            element.getAttribute('http-equiv') || '';

        const normalized =
            httpEquiv.toLowerCase().trim();

        return (
            normalized ===
                'content-security-policy' ||
            normalized ===
                'content-security-policy-report-only'
        );
    }

    function stripCSPMeta(root = document) {
        if (!STRIP_META_CSP || !root) {
            return;
        }

        if (isCSPMeta(root)) {
            root.remove();
            return;
        }

        if (!root.querySelectorAll) {
            return;
        }

        for (const meta of root.querySelectorAll(
            'meta[http-equiv]'
        )) {
            if (isCSPMeta(meta)) {
                meta.remove();
            }
        }
    }

    const computedBackgroundsProcessed =
        new WeakSet();

    function proxyComputedBackground(element) {
        if (!(element instanceof HTMLElement)) {
            return;
        }

        if (
            computedBackgroundsProcessed.has(element)
        ) {
            return;
        }

        computedBackgroundsProcessed.add(element);

        let backgroundImage;

        try {
            backgroundImage =
                getComputedStyle(element)
                    .backgroundImage;
        } catch {
            return;
        }

        if (
            !backgroundImage ||
            backgroundImage === 'none'
        ) {
            return;
        }

        const rewritten =
            rewriteCSSURLs(backgroundImage);

        if (rewritten !== backgroundImage) {
            element.style.backgroundImage =
                rewritten;
        }
    }

    function processElement(element) {
        if (!(element instanceof Element)) {
            return;
        }

        if (isCSPMeta(element)) {
            element.remove();
            return;
        }

        if (element instanceof HTMLImageElement) {
            proxyImage(element);
        }

        if (element instanceof HTMLSourceElement) {
            proxySource(element);
        }

        if (element instanceof HTMLInputElement) {
            proxyInputImage(element);
        }

        if (element instanceof HTMLElement) {
            proxyInlineBackground(element);
        }

        for (const image of element.querySelectorAll('img')) {
            proxyImage(image);
        }

        for (const source of element.querySelectorAll('source')) {
            proxySource(source);
        }

        for (const input of element.querySelectorAll(
            'input[type="image"]'
        )) {
            proxyInputImage(input);
        }

        for (const styled of element.querySelectorAll('[style]')) {
            proxyInlineBackground(styled);
        }

        stripCSPMeta(element);
    }

    function runWhenIdle(callback, timeout = 1000) {
        if ('requestIdleCallback' in window) {
            window.requestIdleCallback(callback, {
                timeout
            });
        } else {
            setTimeout(callback, 0);
        }
    }

    function scanComputedBackgrounds(root = document) {
        if (!root || !root.querySelectorAll) {
            return;
        }

        const elements = root.querySelectorAll('*');
        let index = 0;
        const batchSize = 100;

        function processBatch(deadline) {
            let processed = 0;

            while (
                index < elements.length &&
                processed < batchSize &&
                (
                    !deadline ||
                    deadline.timeRemaining() > 2
                )
            ) {
                proxyComputedBackground(
                    elements[index++]
                );

                processed++;
            }

            if (index < elements.length) {
                runWhenIdle(processBatch);
            }
        }

        runWhenIdle(processBatch);
    }

    function processPage() {
        stripCSPMeta();

        for (const image of document.querySelectorAll('img')) {
            proxyImage(image);
        }

        for (const source of document.querySelectorAll('source')) {
            proxySource(source);
        }

        for (const input of document.querySelectorAll(
            'input[type="image"]'
        )) {
            proxyInputImage(input);
        }

        for (const element of document.querySelectorAll('[style]')) {
            proxyInlineBackground(element);
        }

        scanComputedBackgrounds();

        console.info('[BH2] Page scan completed');
    }

    const pendingElements = new Set();
    let processingScheduled = false;

    function scheduleElement(element) {
        if (!(element instanceof Element)) {
            return;
        }

        pendingElements.add(element);

        if (processingScheduled) {
            return;
        }

        processingScheduled = true;

        setTimeout(() => {
            processingScheduled = false;

            for (const pendingElement of pendingElements) {
                processElement(pendingElement);
            }

            pendingElements.clear();
        }, 50);
    }

    function startObserver() {
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    for (const node of mutation.addedNodes) {
                        if (!(node instanceof Element)) {
                            continue;
                        }

                        stripCSPMeta(node);
                        scheduleElement(node);
                        scanComputedBackgrounds(node);
                    }

                    continue;
                }

                if (mutation.type === 'attributes') {
                    const target = mutation.target;

                    if (
                        mutation.attributeName === 'class' ||
                        mutation.attributeName === 'style'
                    ) {
                        computedBackgroundsProcessed
                            .delete(target);
                    }

                    if (
                        mutation.attributeName === 'http-equiv' &&
                        isCSPMeta(target)
                    ) {
                        target.remove();
                        continue;
                    }

                    scheduleElement(target);
                }
            }
        });

        const target =
            document.documentElement || document;

        observer.observe(target, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: OBSERVED_ATTRIBUTES
        });
    }

    function start() {
        /*
         * Remove CSP meta tags before starting the
         * image and background processing.
         */
        stripCSPMeta();

        startObserver();
        processPage();

        /*
         * Catch images inserted or activated later
         * by JavaScript frameworks and lazy loaders.
         */
        setTimeout(processPage, 1000);
        setTimeout(processPage, 3000);
        setTimeout(processPage, 7000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener(
            'DOMContentLoaded',
            start,
            { once: true }
        );
    } else {
        start();
    }
})();
