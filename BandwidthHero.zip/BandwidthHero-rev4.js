// ==UserScript==
// @name         Bandwidth Hero Rev 4
// @namespace    bandwidth-hero-proxy-2
// @version      4.0.0
// @description  Maximum bandwidth savings for Violentmonkey with early image/picture/preload interception while preserving loading and preload priority semantics.
// @match        *://*/*
// @run-at       document-start
// @inject-into  page
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    /* =========================
       Configuration
       ========================= */

    const PROXY_URL =
        'https://YOUR-NETLIFY-SITE.netlify.app/api/index';

    const EXCLUDED_DOMAINS = [
        'youtube.com',
        'google.com',
        'googleapis.com',
        'facebook.com',
        'instagram.com'
    ];

    const QUALITY = 40;          // 1-100
    const GRAYSCALE = 1;        // 0 = color, 1 = grayscale
    const JPEG = 0;              // 0 = WebP, 1 = JPEG
    const MAX_IMAGE_WIDTH = 1280; // 0 = unlimited
    const STRIP_META_CSP = true;

    /*
     * Image attributes used by normal images and lazy-load libraries.
     * Keep these compatible with the original script.
     */
    const IMAGE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset',
        'data-original',
        'data-original-src',
        'data-lazy',
        'data-image',
        'data-image-src',
        'data-url'
    ];

    const SOURCE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset'
    ];

    const OBSERVED_ATTRIBUTES = [
        ...IMAGE_ATTRIBUTES,
        'style',
        'class',
        'http-equiv',
        'href',
        'rel',
        'as'
    ];

    const PROXY_STATE_KEY = 'bandwidthHeroState';
    const PROXY_ORIGINAL_KEY = 'bandwidthHeroOriginal';

    /*
     * Limits memory use on very long-running tabs.
     * The original cache was unlimited.
     */
    const MAX_PROXY_CACHE = 5000;

    /*
     * Aggressive early interception.
     * Preload rewriting preserves rel/as/fetchpriority so the browser can
     * still prioritize the resource; only the URL is changed.
     */
    const INTERCEPT_IMAGE_PRELOADS = true;
    const INTERCEPT_PICTURE_SOURCES = true;

    let proxyURLObject;
    try {
        proxyURLObject = new URL(PROXY_URL);
    } catch {
        console.error('[BH2] Invalid proxy URL:', PROXY_URL);
        return;
    }

    if (!/^https?:$/.test(proxyURLObject.protocol)) {
        console.error('[BH2] Proxy URL must use HTTP(S):', PROXY_URL);
        return;
    }

    /* =========================
       Domain handling
       ========================= */

    const normalizeDomain = domain =>
        String(domain)
            .toLowerCase()
            .trim()
            .replace(/^https?:\/\//, '')
            .replace(/^www\./, '')
            .split('/')[0]
            .split(':')[0];

    const excludedDomains = new Set(
        EXCLUDED_DOMAINS.map(normalizeDomain)
    );

    function isExcludedDomain(hostname) {
        const host = String(hostname || '')
            .toLowerCase()
            .replace(/^www\./, '');

        for (const domain of excludedDomains) {
            if (host === domain || host.endsWith(`.${domain}`)) {
                return true;
            }
        }
        return false;
    }

    if (isExcludedDomain(location.hostname)) {
        console.info('[BH2] Domain excluded:', location.hostname);
        return;
    }

    /* =========================
       URL / proxy cache
       ========================= */

    const proxyCache = new Map();

    function cacheGet(key) {
        const value = proxyCache.get(key);
        if (value !== undefined) {
            // Refresh LRU position.
            proxyCache.delete(key);
            proxyCache.set(key, value);
        }
        return value;
    }

    function cacheSet(key, value) {
        proxyCache.set(key, value);

        if (proxyCache.size > MAX_PROXY_CACHE) {
            const oldest = proxyCache.keys().next().value;
            proxyCache.delete(oldest);
        }
    }

    function isProxyURL(value) {
        if (!value || typeof value !== 'string') return false;

        try {
            const parsed = new URL(
                value,
                document.baseURI || location.href
            );

            return (
                parsed.origin === proxyURLObject.origin &&
                parsed.pathname === proxyURLObject.pathname
            );
        } catch {
            return false;
        }
    }

    function getAbsoluteURL(value) {
        if (!value || typeof value !== 'string') return null;

        const input = value.trim();

        if (
            !input ||
            input.startsWith('data:') ||
            input.startsWith('blob:') ||
            input.startsWith('javascript:') ||
            input.startsWith('#') ||
            input.startsWith('about:')
        ) {
            return null;
        }

        try {
            return new URL(
                input,
                document.baseURI || location.href
            ).href;
        } catch {
            return null;
        }
    }

    function getProxyURL(originalURL) {
        const absoluteURL = getAbsoluteURL(originalURL);

        if (!absoluteURL || isProxyURL(absoluteURL)) {
            return null;
        }

        const cached = cacheGet(absoluteURL);
        if (cached) return cached;

        const proxy = new URL(PROXY_URL);

        // Bandwidth Hero Proxy 2 compatible parameters.
        proxy.searchParams.set('url', absoluteURL);
        proxy.searchParams.set('quality', String(QUALITY));
        proxy.searchParams.set('l', String(QUALITY));
        proxy.searchParams.set('bw', String(GRAYSCALE));
        proxy.searchParams.set('jpeg', String(JPEG));

        if (
            Number.isFinite(MAX_IMAGE_WIDTH) &&
            MAX_IMAGE_WIDTH > 0
        ) {
            proxy.searchParams.set(
                'max_width',
                String(Math.floor(MAX_IMAGE_WIDTH))
            );
        }

        const result = proxy.href;
        cacheSet(absoluteURL, result);
        return result;
    }

    /* =========================
       Attribute rewriting
       ========================= */

    function rewriteSrcset(srcset) {
        if (!srcset) return srcset;

        let changed = false;

        const rewritten = srcset
            .split(',')
            .map(item => {
                const trimmed = item.trim();
                if (!trimmed) return item;

                const parts = trimmed.split(/\s+/);
                const originalURL = parts.shift();
                const proxiedURL = getProxyURL(originalURL);

                if (!proxiedURL) return trimmed;

                changed = true;
                return [proxiedURL, ...parts].join(' ');
            })
            .join(', ');

        return changed ? rewritten : srcset;
    }

    function rewriteCSSURLs(value) {
        if (!value || value === 'none') return value;

        return value.replace(
            /url\(\s*(['"]?)(.*?)\1\s*\)/gi,
            (match, quote, originalURL) => {
                const proxiedURL = getProxyURL(originalURL);

                if (!proxiedURL) return match;
                return `url("${proxiedURL}")`;
            }
        );
    }

    function getImageState(image) {
        let state = '';

        for (const attribute of IMAGE_ATTRIBUTES) {
            state += attribute;
            state += ':';
            state += image.getAttribute(attribute) || '';
            state += '|';
        }

        return state;
    }


    /* =========================
       Early JavaScript prehook
       ========================= */

    /*
     * These hooks run before normal DOM/MutationObserver fallback processing.
     * They use the original native implementations internally to avoid
     * recursive interception.
     */
    const nativeImageSrc =
        Object.getOwnPropertyDescriptor(
            HTMLImageElement.prototype,
            'src'
        );

    const nativeImageSrcset =
        Object.getOwnPropertyDescriptor(
            HTMLImageElement.prototype,
            'srcset'
        );

    const nativeImageLoading =
        Object.getOwnPropertyDescriptor(
            HTMLImageElement.prototype,
            'loading'
        );

    const nativeLinkHref =
        Object.getOwnPropertyDescriptor(
            HTMLLinkElement.prototype,
            'href'
        );

    const nativeSourceSrc =
        Object.getOwnPropertyDescriptor(
            HTMLSourceElement.prototype,
            'src'
        );

    const nativeSourceSrcset =
        Object.getOwnPropertyDescriptor(
            HTMLSourceElement.prototype,
            'srcset'
        );

    const nativeSetAttribute =
        Element.prototype.setAttribute;

    const NativeImage =
        window.Image;

    function shouldRewriteAttribute(name) {
        return IMAGE_ATTRIBUTES.includes(
            String(name).toLowerCase()
        );
    }

    function rewriteAttributeValue(name, value) {
        if (value == null) return value;

        const attr = String(name).toLowerCase();

        if (attr.includes('srcset')) {
            return rewriteSrcset(String(value));
        }

        const proxy = getProxyURL(String(value));
        return proxy || value;
    }

    function isImagePreload(link) {
        if (!(link instanceof HTMLLinkElement)) return false;

        const rel = (link.getAttribute('rel') || '')
            .toLowerCase()
            .split(/\s+/);

        const as = (link.getAttribute('as') || '')
            .toLowerCase();

        return (
            INTERCEPT_IMAGE_PRELOADS &&
            rel.includes('preload') &&
            as === 'image'
        );
    }

    function rewriteImagePreloadHref(link, value) {
        if (!isImagePreload(link)) return value;

        const original = String(value);
        const proxy = getProxyURL(original);

        if (proxy && proxy !== original) {
            if (!link.dataset[PROXY_ORIGINAL_KEY]) {
                nativeSetAttribute.call(
                    link,
                    'data-bandwidth-hero-original',
                    getAbsoluteURL(original) || original
                );
            }
            return proxy;
        }

        return value;
    }

    function installPrehook() {
        /*
         * HTMLImageElement.loading
         *
         * We intentionally preserve the site's value. The property is
         * observed rather than modified, because forcing eager/lazy loading
         * can hurt LCP or increase bandwidth.
         */
        if (
            nativeImageLoading &&
            typeof nativeImageLoading.get === 'function' &&
            typeof nativeImageLoading.set === 'function'
        ) {
            try {
                Object.defineProperty(
                    HTMLImageElement.prototype,
                    'loading',
                    {
                        configurable: nativeImageLoading.configurable,
                        enumerable: nativeImageLoading.enumerable,
                        get: nativeImageLoading.get,
                        set(value) {
                            return nativeImageLoading.set.call(
                                this,
                                value
                            );
                        }
                    }
                );
            } catch (error) {
                console.warn(
                    '[BH2] Unable to preserve HTMLImageElement.loading hook:',
                    error
                );
            }
        }

        /*
         * HTMLImageElement.src
         */
        if (
            nativeImageSrc &&
            typeof nativeImageSrc.get === 'function' &&
            typeof nativeImageSrc.set === 'function'
        ) {
            try {
                Object.defineProperty(
                    HTMLImageElement.prototype,
                    'src',
                    {
                        configurable: nativeImageSrc.configurable,
                        enumerable: nativeImageSrc.enumerable,
                        get: nativeImageSrc.get,
                        set(value) {
                            const original = String(value);
                            const rewritten =
                                getProxyURL(original) || original;

                            nativeImageSrc.set.call(
                                this,
                                rewritten
                            );

                            if (
                                rewritten !== original &&
                                !this.dataset[PROXY_ORIGINAL_KEY]
                            ) {
                                this.dataset[PROXY_ORIGINAL_KEY] =
                                    getAbsoluteURL(original) || original;
                            }
                        }
                    }
                );
            } catch (error) {
                console.warn(
                    '[BH2] Unable to hook HTMLImageElement.src:',
                    error
                );
            }
        }

        /*
         * HTMLImageElement.srcset
         */
        if (
            nativeImageSrcset &&
            typeof nativeImageSrcset.get === 'function' &&
            typeof nativeImageSrcset.set === 'function'
        ) {
            try {
                Object.defineProperty(
                    HTMLImageElement.prototype,
                    'srcset',
                    {
                        configurable: nativeImageSrcset.configurable,
                        enumerable: nativeImageSrcset.enumerable,
                        get: nativeImageSrcset.get,
                        set(value) {
                            const original = String(value);
                            const rewritten =
                                rewriteSrcset(original);

                            nativeImageSrcset.set.call(
                                this,
                                rewritten
                            );
                        }
                    }
                );
            } catch (error) {
                console.warn(
                    '[BH2] Unable to hook HTMLImageElement.srcset:',
                    error
                );
            }
        }

        /*
         * <picture>/<source> URL properties.
         * These are rewritten only when they point to image resources.
         */
        if (INTERCEPT_PICTURE_SOURCES) {
            if (
                nativeSourceSrc &&
                typeof nativeSourceSrc.get === 'function' &&
                typeof nativeSourceSrc.set === 'function'
            ) {
                try {
                    Object.defineProperty(
                        HTMLSourceElement.prototype,
                        'src',
                        {
                            configurable: nativeSourceSrc.configurable,
                            enumerable: nativeSourceSrc.enumerable,
                            get: nativeSourceSrc.get,
                            set(value) {
                                const original = String(value);
                                const rewritten =
                                    getProxyURL(original) || original;
                                nativeSourceSrc.set.call(
                                    this,
                                    rewritten
                                );
                            }
                        }
                    );
                } catch (error) {
                    console.warn(
                        '[BH2] Unable to hook HTMLSourceElement.src:',
                        error
                    );
                }
            }

            if (
                nativeSourceSrcset &&
                typeof nativeSourceSrcset.get === 'function' &&
                typeof nativeSourceSrcset.set === 'function'
            ) {
                try {
                    Object.defineProperty(
                        HTMLSourceElement.prototype,
                        'srcset',
                        {
                            configurable: nativeSourceSrcset.configurable,
                            enumerable: nativeSourceSrcset.enumerable,
                            get: nativeSourceSrcset.get,
                            set(value) {
                                nativeSourceSrcset.set.call(
                                    this,
                                    rewriteSrcset(String(value))
                                );
                            }
                        }
                    );
                } catch (error) {
                    console.warn(
                        '[BH2] Unable to hook HTMLSourceElement.srcset:',
                        error
                    );
                }
            }
        }

        /*
         * Element.setAttribute()
         *
         * This catches lazy-load libraries that use:
         * setAttribute('src', ...)
         * setAttribute('data-src', ...)
         * setAttribute('srcset', ...)
         */
        try {
            Element.prototype.setAttribute =
                function(name, value) {
                    if (
                        this instanceof HTMLImageElement &&
                        shouldRewriteAttribute(name)
                    ) {
                        const original = String(value);
                        const rewritten =
                            rewriteAttributeValue(
                                name,
                                original
                            );

                        if (
                            rewritten !== original &&
                            !this.dataset[PROXY_ORIGINAL_KEY]
                        ) {
                            this.dataset[PROXY_ORIGINAL_KEY] =
                                getAbsoluteURL(original) || original;
                        }

                        return nativeSetAttribute.call(
                            this,
                            name,
                            rewritten
                        );
                    }

                    /*
                     * Dynamically assigned <picture><source> attributes.
                     */
                    if (
                        INTERCEPT_PICTURE_SOURCES &&
                        this instanceof HTMLSourceElement &&
                        shouldRewriteAttribute(name)
                    ) {
                        const original = String(value);
                        const rewritten =
                            rewriteAttributeValue(name, original);

                        return nativeSetAttribute.call(
                            this,
                            name,
                            rewritten
                        );
                    }

                    /*
                     * <link rel="preload" as="image">.
                     * Preserve preload semantics; rewrite only href.
                     */
                    if (
                        INTERCEPT_IMAGE_PRELOADS &&
                        this instanceof HTMLLinkElement &&
                        (
                            String(name).toLowerCase() === 'rel' ||
                            String(name).toLowerCase() === 'as'
                        )
                    ) {
                        const result = nativeSetAttribute.call(
                            this,
                            name,
                            value
                        );

                        /*
                         * If href was assigned first and rel/as later makes
                         * this an image preload, rewrite href now.
                         */
                        if (isImagePreload(this)) {
                            const href = nativeLinkHref.get.call(this);
                            const rewritten =
                                rewriteImagePreloadHref(this, href);

                            if (rewritten !== href) {
                                nativeLinkHref.set.call(this, rewritten);
                            }
                        }

                        return result;
                    }

                    if (
                        INTERCEPT_IMAGE_PRELOADS &&
                        this instanceof HTMLLinkElement &&
                        String(name).toLowerCase() === 'href' &&
                        isImagePreload(this)
                    ) {
                        const rewritten =
                            rewriteImagePreloadHref(this, value);

                        return nativeSetAttribute.call(
                            this,
                            name,
                            rewritten
                        );
                    }

                    return nativeSetAttribute.call(
                        this,
                        name,
                        value
                    );
                };
        } catch (error) {
            console.warn(
                '[BH2] Unable to hook Element.setAttribute:',
                error
            );
        }

        /*
         * Image()
         *
         * Preserve the native constructor semantics as closely as possible.
         */
        try {
            const WrappedImage = function(width, height) {
                const image =
                    arguments.length === 0
                        ? new NativeImage()
                        : new NativeImage(width, height);

                return image;
            };

            WrappedImage.prototype =
                NativeImage.prototype;

            window.Image = WrappedImage;
        } catch (error) {
            console.warn(
                '[BH2] Unable to hook Image():',
                error
            );
        }
    }

    /* =========================
       Image processing
       ========================= */

    function installImageErrorHandler(image) {
        if (image.dataset.bandwidthHeroErrorHandler) return;

        image.dataset.bandwidthHeroErrorHandler = '1';

        image.addEventListener('error', () => {
            const originalURL =
                image.dataset[PROXY_ORIGINAL_KEY];

            if (
                originalURL &&
                !isProxyURL(originalURL)
            ) {
                console.warn(
                    '[BH2] Proxy failed; restoring original image'
                );

                // Prevent repeated proxying of the restored URL.
                image.dataset[PROXY_ORIGINAL_KEY] = '';
                image.src = originalURL;
            }
        });
    }

    function proxyImage(image) {
        if (!(image instanceof HTMLImageElement)) return;

        const state = getImageState(image);

        if (image.dataset[PROXY_STATE_KEY] === state) {
            return;
        }

        image.dataset[PROXY_STATE_KEY] = state;

        for (const attribute of IMAGE_ATTRIBUTES) {
            const value = image.getAttribute(attribute);
            if (!value) continue;

            if (attribute.includes('srcset')) {
                const rewritten = rewriteSrcset(value);

                if (rewritten !== value) {
                    image.setAttribute(attribute, rewritten);
                }

                continue;
            }

            const proxiedURL = getProxyURL(value);

            if (
                proxiedURL &&
                proxiedURL !== value
            ) {
                image.setAttribute(attribute, proxiedURL);
            }
        }

        const currentURL =
            image.getAttribute('src') ||
            image.currentSrc ||
            image.src;

        if (
            !currentURL ||
            isProxyURL(currentURL)
        ) {
            return;
        }

        const proxiedCurrentURL =
            getProxyURL(currentURL);

        if (!proxiedCurrentURL) return;

        if (!image.dataset[PROXY_ORIGINAL_KEY]) {
            image.dataset[PROXY_ORIGINAL_KEY] = currentURL;
        }

        installImageErrorHandler(image);

        image.setAttribute('src', proxiedCurrentURL);
    }

    function proxySource(source) {
        if (!(source instanceof HTMLSourceElement)) return;

        for (const attribute of SOURCE_ATTRIBUTES) {
            const value = source.getAttribute(attribute);
            if (!value) continue;

            if (attribute.includes('srcset')) {
                const rewritten = rewriteSrcset(value);

                if (rewritten !== value) {
                    source.setAttribute(attribute, rewritten);
                }

                continue;
            }

            const proxiedURL = getProxyURL(value);

            if (
                proxiedURL &&
                proxiedURL !== value
            ) {
                source.setAttribute(attribute, proxiedURL);
            }
        }
    }

    function proxyInputImage(input) {
        if (
            !(input instanceof HTMLInputElement) ||
            input.type !== 'image'
        ) {
            return;
        }

        const src = input.getAttribute('src');
        if (!src) return;

        const proxiedURL = getProxyURL(src);

        if (
            proxiedURL &&
            proxiedURL !== src
        ) {
            input.setAttribute('src', proxiedURL);
        }
    }

    function proxyInlineBackground(element) {
        if (!(element instanceof HTMLElement)) return;

        const style = element.getAttribute('style');
        if (!style) return;

        const rewritten = rewriteCSSURLs(style);

        if (rewritten !== style) {
            element.setAttribute('style', rewritten);
        }
    }

    /* =========================
       CSP handling
       ========================= */

    function isCSPMeta(element) {
        if (!(element instanceof HTMLMetaElement)) {
            return false;
        }

        const httpEquiv =
            element.getAttribute('http-equiv') || '';

        const normalized =
            httpEquiv.toLowerCase().trim();

        return (
            normalized === 'content-security-policy' ||
            normalized === 'content-security-policy-report-only'
        );
    }

    function stripCSPMeta(root = document) {
        if (!STRIP_META_CSP || !root) return;

        if (isCSPMeta(root)) {
            root.remove();
            return;
        }

        if (!root.querySelectorAll) return;

        for (const meta of root.querySelectorAll(
            'meta[http-equiv]'
        )) {
            if (isCSPMeta(meta)) {
                meta.remove();
            }
        }
    }

    /* =========================
       Computed CSS backgrounds
       ========================= */

    const computedBackgroundsProcessed = new WeakSet();

    function proxyComputedBackground(element) {
        if (!(element instanceof HTMLElement)) return;

        if (computedBackgroundsProcessed.has(element)) {
            return;
        }

        computedBackgroundsProcessed.add(element);

        let backgroundImage;

        try {
            backgroundImage =
                getComputedStyle(element).backgroundImage;
        } catch {
            return;
        }

        if (
            !backgroundImage ||
            backgroundImage === 'none'
        ) {
            return;
        }

        const rewritten =
            rewriteCSSURLs(backgroundImage);

        if (rewritten !== backgroundImage) {
            element.style.backgroundImage = rewritten;
        }
    }

    function scanComputedBackgrounds(root = document) {
        if (!root || !root.querySelectorAll) return;

        /*
         * Only inspect elements that can actually have a style/class.
         * This avoids a second full pass over text/comment nodes.
         */
        const elements = root.querySelectorAll(
            '[style], [class]'
        );

        let index = 0;
        const batchSize = 80;

        const processBatch = deadline => {
            let processed = 0;

            while (
                index < elements.length &&
                processed < batchSize &&
                (
                    !deadline ||
                    deadline.timeRemaining() > 2
                )
            ) {
                proxyComputedBackground(elements[index++]);
                processed++;
            }

            if (index < elements.length) {
                scheduleIdle(processBatch, 1000);
            }
        };

        scheduleIdle(processBatch, 1000);
    }

    /* =========================
       DOM processing
       ========================= */

    function processElement(element) {
        if (!(element instanceof Element)) return;

        if (
            INTERCEPT_IMAGE_PRELOADS &&
            element instanceof HTMLLinkElement &&
            isImagePreload(element)
        ) {
            const href = element.getAttribute('href');
            if (href) {
                const rewritten = rewriteImagePreloadHref(element, href);
                if (rewritten !== href) {
                    nativeSetAttribute.call(
                        element,
                        'href',
                        rewritten
                    );
                }
            }
        }

        if (isCSPMeta(element)) {
            element.remove();
            return;
        }

        if (element instanceof HTMLImageElement) {
            proxyImage(element);
        }

        if (element instanceof HTMLSourceElement) {
            proxySource(element);
        }

        if (element instanceof HTMLInputElement) {
            proxyInputImage(element);
        }

        if (element instanceof HTMLElement) {
            proxyInlineBackground(element);
        }

        /*
         * Process descendants only once per queued root.
         * This is much cheaper than recursively scheduling every child.
         */
        const images = element.querySelectorAll('img');
        for (const image of images) {
            proxyImage(image);
        }

        const sources = element.querySelectorAll('source');
        for (const source of sources) {
            proxySource(source);
        }

        const inputs = element.querySelectorAll(
            'input[type="image"]'
        );
        for (const input of inputs) {
            proxyInputImage(input);
        }

        const styled = element.querySelectorAll('[style]');
        for (const node of styled) {
            proxyInlineBackground(node);
        }

        if (INTERCEPT_IMAGE_PRELOADS) {
            const preloads = element.querySelectorAll(
                'link[rel~="preload"][as="image"]'
            );
            for (const link of preloads) {
                const href = link.getAttribute('href');
                if (href) {
                    const rewritten =
                        rewriteImagePreloadHref(link, href);
                    if (rewritten !== href) {
                        nativeSetAttribute.call(
                            link,
                            'href',
                            rewritten
                        );
                    }
                }
            }
        }

        stripCSPMeta(element);
    }

    function scheduleIdle(callback, timeout = 1000) {
        if (typeof window.requestIdleCallback === 'function') {
            window.requestIdleCallback(callback, { timeout });
        } else {
            setTimeout(() => callback(null), 0);
        }
    }

    function processPage() {
        stripCSPMeta();

        /*
         * querySelectorAll is intentionally grouped by element type.
         * This keeps the hot path simple and avoids repeated descendant
         * queries for every individual node.
         */
        for (const image of document.images) {
            proxyImage(image);
        }

        for (const source of document.querySelectorAll('source')) {
            proxySource(source);
        }

        for (const input of document.querySelectorAll(
            'input[type="image"]'
        )) {
            proxyInputImage(input);
        }

        for (const element of document.querySelectorAll('[style]')) {
            proxyInlineBackground(element);
        }

        if (INTERCEPT_IMAGE_PRELOADS) {
            for (const link of document.querySelectorAll(
                'link[rel~="preload"][as="image"]'
            )) {
                const href = link.getAttribute('href');
                if (href) {
                    const rewritten =
                        rewriteImagePreloadHref(link, href);
                    if (rewritten !== href) {
                        nativeSetAttribute.call(
                            link,
                            'href',
                            rewritten
                        );
                    }
                }
            }
        }

        scanComputedBackgrounds();

        console.info('[BH2] Page scan completed');
    }

    /* =========================
       Mutation batching
       ========================= */

    const pendingElements = new Set();
    let processingScheduled = false;

    function scheduleElement(element) {
        if (!(element instanceof Element)) return;

        pendingElements.add(element);

        if (processingScheduled) return;

        processingScheduled = true;

        /*
         * A short debounce collapses bursts from React/Vue/Angular,
         * lazy loaders and infinite scrolling into one processing pass.
         */
        setTimeout(() => {
            processingScheduled = false;

            if (!pendingElements.size) return;

            const elements = Array.from(pendingElements);
            pendingElements.clear();

            for (const pendingElement of elements) {
                if (pendingElement.isConnected) {
                    processElement(pendingElement);
                }
            }
        }, 40);
    }

    function startObserver() {
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    for (const node of mutation.addedNodes) {
                        if (!(node instanceof Element)) continue;

                        stripCSPMeta(node);
                        scheduleElement(node);

                        /*
                         * Computed styles are deferred and only scanned
                         * for the newly-added subtree.
                         */
                        scanComputedBackgrounds(node);
                    }

                    continue;
                }

                if (mutation.type === 'attributes') {
                    const target = mutation.target;

                    if (
                        mutation.attributeName === 'class' ||
                        mutation.attributeName === 'style'
                    ) {
                        computedBackgroundsProcessed.delete(target);
                    }

                    if (
                        mutation.attributeName === 'http-equiv' &&
                        isCSPMeta(target)
                    ) {
                        target.remove();
                        continue;
                    }

                    scheduleElement(target);
                }
            }
        });

        /*
         * Observe as early as possible. If documentElement does not
         * exist yet, observe document until it is available.
         */
        const target =
            document.documentElement || document;

        observer.observe(target, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: OBSERVED_ATTRIBUTES
        });
    }

    /* =========================
       Startup
       ========================= */

    function start() {
        /*
         * Install JavaScript hooks before the normal fallback scans.
         */
        installPrehook();


        stripCSPMeta();
        startObserver();

        /*
         * Run immediately. Unlike the original version, startup does not
         * wait for DOMContentLoaded, reducing the chance of the original
         * image being requested before it is rewritten.
         */
        processPage();

        /*
         * Follow-up passes remain for lazy loaders and frameworks that
         * activate images after initial page construction.
         */
        setTimeout(processPage, 1000);
        setTimeout(processPage, 3000);
        setTimeout(processPage, 7000);
    }

    start();
})();
