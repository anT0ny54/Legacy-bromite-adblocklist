Bandwidth Hero
====================================================

Violentmonkey & Tampermonkey userscript for bandwidth-hero-proxy2.

INSTALL
-------
1. Open BandwidthHero-rev*.js
2. Replace:
   https://YOUR-NETLIFY-SITE.netlify.app/api/index
   with your deployed bandwidth-hero-proxy2 endpoint.
3. Install the .js file in Violentmonkey.

DEFAULT MAX-SAVINGS PROFILE
---------------------------
QUALITY = 40
GRAYSCALE = 1
JPEG = 0 (WebP)
MAX_IMAGE_WIDTH = 1280

EXCLUDED DOMAINS = "
        'youtube.com',
        'google.com',
        'googleapis.com',
        'facebook.com',
        'instagram.com'
    "


IMPORTANT
---------
The userscript cannot remove CSP supplied as an HTTP response header. It can only remove
CSP meta elements from the DOM.

The proxy itself fetches the original image and transforms it. Use a proxy you trust.
The referenced bandwidth-hero-proxy2 project documents that the proxy can forward relevant
browser headers/cookies to the origin when fetching protected images.
