// ==UserScript==
// @name         Bandwidth Hero Rev 5
// @namespace    bandwidth-hero-proxy-2
// @version      5.0.0
// @description  Aggressive image bandwidth reduction with an early, safe page prehook. Rewrites JS-created images, picture/source candidates, image preloads, lazy attributes, and explicit CSS backgrounds while preserving loading/fetchpriority semantics.
// @match        *://*/*
// @run-at       document-start
// @inject-into  page
// @grant        none
// ==/UserScript==

(() => {
    'use strict';

    /* =========================
       Configuration
       ========================= */

    // REQUIRED: replace with your deployed bandwidth-hero-proxy2 endpoint.
    const PROXY_URL = 'https://YOUR-NETLIFY-SITE.netlify.app/api/index';

    // Add domains where proxying should never occur.
    const EXCLUDED_DOMAINS = [
        'youtube.com',
        'google.com',
        'googleapis.com',
        'facebook.com',
        'instagram.com'
    ];

    // Maximum savings profile.
    const QUALITY = 40;            // 1-100; lower = smaller output
    const GRAYSCALE = 1;           // 0 = color, 1 = grayscale
    const JPEG = 0;                // 0 = WebP, 1 = JPEG
    const MAX_IMAGE_WIDTH = 1280;  // 0 = unlimited

    // Remove HTML meta CSP tags that could block proxy-served images.
    // Browser/network response CSP headers cannot be removed by a userscript.
    const STRIP_META_CSP = true;

    // Preload interception is enabled, but only for unambiguous image preloads.
    const INTERCEPT_IMAGE_PRELOADS = true;
    const INTERCEPT_PICTURE_SOURCES = true;

    // Explicit lazy-load attributes commonly used by image libraries.
    const IMAGE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset',
        'data-original',
        'data-original-src',
        'data-lazy',
        'data-image',
        'data-image-src',
        'data-url'
    ];

    const SOURCE_ATTRIBUTES = [
        'src',
        'srcset',
        'data-src',
        'data-srcset',
        'data-lazy-src',
        'data-lazy-srcset'
    ];

    const OBSERVED_ATTRIBUTES = Array.from(new Set([
        ...IMAGE_ATTRIBUTES,
        'style',
        'class',
        'http-equiv',
        'href',
        'rel',
        'as'
    ]));

    const ORIGINAL_ATTR = 'data-bandwidth-hero-original';
    const STATE_ATTR = 'data-bandwidth-hero-state';
    const MAX_PROXY_CACHE = 5000;

    let proxyBase;
    try {
        proxyBase = new URL(PROXY_URL);
    } catch {
        console.error('[BandwidthHero] Invalid PROXY_URL:', PROXY_URL);
        return;
    }

    if (!/^https?:$/.test(proxyBase.protocol)) {
        console.error('[BandwidthHero] PROXY_URL must use HTTP(S):', PROXY_URL);
        return;
    }

    const normalizeDomain = value => String(value || '')
        .toLowerCase()
        .trim()
        .replace(/^https?:\/\//, '')
        .replace(/^www\./, '')
        .split('/')[0]
        .split(':')[0];

    const excludedDomains = new Set(EXCLUDED_DOMAINS.map(normalizeDomain));

    function isExcludedDomain(hostname) {
        const host = normalizeDomain(hostname);
        for (const domain of excludedDomains) {
            if (host === domain || host.endsWith(`.${domain}`)) return true;
        }
        return false;
    }

    if (isExcludedDomain(location.hostname)) {
        return;
    }

    /* =========================
       URL handling + cache
       ========================= */

    const proxyCache = new Map();

    function rememberProxy(key, value) {
        if (proxyCache.has(key)) proxyCache.delete(key);
        proxyCache.set(key, value);
        while (proxyCache.size > MAX_PROXY_CACHE) {
            proxyCache.delete(proxyCache.keys().next().value);
        }
        return value;
    }

    function absoluteURL(value) {
        if (!value) return null;
        try {
            return new URL(value, document.baseURI || location.href).href;
        } catch {
            return null;
        }
    }

    function isSkippableURL(value) {
        const text = String(value || '').trim();
        if (!text) return true;
        if (text.startsWith('#')) return true;
        if (/^(?:data|blob|javascript|about):/i.test(text)) return true;
        return false;
    }

    function shouldProxyURL(value) {
        if (isSkippableURL(value)) return false;

        const absolute = absoluteURL(value);
        if (!absolute) return false;

        let url;
        try {
            url = new URL(absolute);
        } catch {
            return false;
        }

        if (!/^https?:$/.test(url.protocol)) return false;
        if (url.origin === proxyBase.origin && url.pathname === proxyBase.pathname) {
            return false;
        }
        if (isExcludedDomain(url.hostname)) return false;
        return true;
    }

    function getProxyURL(value) {
        if (!shouldProxyURL(value)) return null;

        const absolute = absoluteURL(value);
        if (!absolute) return null;

        const cached = proxyCache.get(absolute);
        if (cached) return cached;

        try {
            const proxy = new URL(proxyBase.href);
            proxy.searchParams.set('url', absolute);
            proxy.searchParams.set('quality', String(QUALITY));
            // l is retained for compatibility with older Bandwidth Hero clients.
            proxy.searchParams.set('l', String(QUALITY));
            proxy.searchParams.set('bw', String(GRAYSCALE ? 1 : 0));
            proxy.searchParams.set('jpeg', String(JPEG ? 1 : 0));
            proxy.searchParams.set('max_width', String(Math.max(0, Math.floor(MAX_IMAGE_WIDTH))));
            return rememberProxy(absolute, proxy.href);
        } catch {
            return null;
        }
    }

    function rewriteSrcset(value) {
        if (!value) return value;
        let changed = false;

        const result = String(value).split(',').map(candidate => {
            const text = candidate.trim();
            if (!text) return candidate;

            // Preserve descriptors such as 400w / 2x.
            const match = text.match(/^(\S+)([\s\S]*)$/);
            if (!match) return candidate;

            const original = match[1];
            const proxy = getProxyURL(original);
            if (!proxy) return candidate;

            changed = true;
            return proxy + match[2];
        }).join(', ');

        return changed ? result : value;
    }

    function rewriteCSSURLs(value) {
        if (!value || value === 'none') return value;
        return String(value).replace(
            /url\(\s*(['"]?)(.*?)\1\s*\)/gi,
            (match, quote, original) => {
                const proxy = getProxyURL(original);
                return proxy ? `url("${proxy}")` : match;
            }
        );
    }

    /* =========================
       Native references
       ========================= */

    const nativeImageSrc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    const nativeImageSrcset = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'srcset');
    const nativeSourceSrc = Object.getOwnPropertyDescriptor(HTMLSourceElement.prototype, 'src');
    const nativeSourceSrcset = Object.getOwnPropertyDescriptor(HTMLSourceElement.prototype, 'srcset');
    const nativeLinkHref = Object.getOwnPropertyDescriptor(HTMLLinkElement.prototype, 'href');
    const nativeSetAttribute = Element.prototype.setAttribute;
    const nativeRemoveAttribute = Element.prototype.removeAttribute;
    const NativeImage = window.Image;

    const hooked = new WeakSet();

    function setOriginal(element, original) {
        if (!(element instanceof Element) || !original) return;
        if (!element.getAttribute(ORIGINAL_ATTR)) {
            try {
                nativeSetAttribute.call(element, ORIGINAL_ATTR, absoluteURL(original) || String(original));
            } catch {}
        }
    }

    function safeSetAttribute(element, name, value) {
        try {
            nativeSetAttribute.call(element, name, value);
        } catch {}
    }

    function rewriteAttributeValue(name, value) {
        if (value == null) return value;
        const attr = String(name).toLowerCase();
        if (attr.includes('srcset')) return rewriteSrcset(String(value));
        return getProxyURL(String(value)) || value;
    }

    function isImagePreload(link) {
        if (!INTERCEPT_IMAGE_PRELOADS || !(link instanceof HTMLLinkElement)) return false;
        const rel = (link.getAttribute('rel') || '').toLowerCase().split(/\s+/);
        const as = (link.getAttribute('as') || '').toLowerCase();
        return rel.includes('preload') && as === 'image';
    }

    function rewritePreload(link) {
        if (!isImagePreload(link)) return;
        const href = link.getAttribute('href');
        if (!href) return;
        const proxy = getProxyURL(href);
        if (proxy && proxy !== href) {
            setOriginal(link, href);
            safeSetAttribute(link, 'href', proxy);
        }
    }

    /* =========================
       Safe early prehook
       ========================= */

    function installPrehook() {
        // HTMLImageElement.src
        if (nativeImageSrc?.get && nativeImageSrc?.set) {
            try {
                Object.defineProperty(HTMLImageElement.prototype, 'src', {
                    configurable: nativeImageSrc.configurable,
                    enumerable: nativeImageSrc.enumerable,
                    get: nativeImageSrc.get,
                    set(value) {
                        const original = String(value);
                        const proxy = getProxyURL(original);
                        if (proxy) setOriginal(this, original);
                        return nativeImageSrc.set.call(this, proxy || value);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero] src hook failed:', e);
            }
        }

        // HTMLImageElement.srcset
        if (nativeImageSrcset?.get && nativeImageSrcset?.set) {
            try {
                Object.defineProperty(HTMLImageElement.prototype, 'srcset', {
                    configurable: nativeImageSrcset.configurable,
                    enumerable: nativeImageSrcset.enumerable,
                    get: nativeImageSrcset.get,
                    set(value) {
                        const original = String(value);
                        const rewritten = rewriteSrcset(original);
                        if (rewritten !== original) setOriginal(this, original);
                        return nativeImageSrcset.set.call(this, rewritten);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero] srcset hook failed:', e);
            }
        }

        // <source> inside <picture>.
        if (INTERCEPT_PICTURE_SOURCES && nativeSourceSrc?.get && nativeSourceSrc?.set) {
            try {
                Object.defineProperty(HTMLSourceElement.prototype, 'src', {
                    configurable: nativeSourceSrc.configurable,
                    enumerable: nativeSourceSrc.enumerable,
                    get: nativeSourceSrc.get,
                    set(value) {
                        const original = String(value);
                        const proxy = getProxyURL(original);
                        if (proxy) setOriginal(this, original);
                        return nativeSourceSrc.set.call(this, proxy || value);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero] source.src hook failed:', e);
            }
        }

        if (INTERCEPT_PICTURE_SOURCES && nativeSourceSrcset?.get && nativeSourceSrcset?.set) {
            try {
                Object.defineProperty(HTMLSourceElement.prototype, 'srcset', {
                    configurable: nativeSourceSrcset.configurable,
                    enumerable: nativeSourceSrcset.enumerable,
                    get: nativeSourceSrcset.get,
                    set(value) {
                        const original = String(value);
                        const rewritten = rewriteSrcset(original);
                        if (rewritten !== original) setOriginal(this, original);
                        return nativeSourceSrcset.set.call(this, rewritten);
                    }
                });
            } catch (e) {
                console.warn('[BandwidthHero] source.srcset hook failed:', e);
            }
        }

        // setAttribute catches parser-adjacent framework assignments and lazy attributes.
        try {
            Element.prototype.setAttribute = function(name, value) {
                const attr = String(name).toLowerCase();
                let next = value;

                if (this instanceof HTMLImageElement || this instanceof HTMLSourceElement) {
                    if (IMAGE_ATTRIBUTES.includes(attr) || SOURCE_ATTRIBUTES.includes(attr)) {
                        next = rewriteAttributeValue(attr, value);
                        if (String(next) !== String(value)) setOriginal(this, value);
                    }
                }

                if (this instanceof HTMLLinkElement && attr === 'href' && isImagePreload(this)) {
                    const proxy = getProxyURL(String(value));
                    if (proxy) {
                        setOriginal(this, value);
                        next = proxy;
                    }
                }

                return nativeSetAttribute.call(this, name, next);
            };
        } catch (e) {
            console.warn('[BandwidthHero] setAttribute hook failed:', e);
        }

        // new Image(width, height) is a common JS image creation path.
        if (typeof NativeImage === 'function') {
            try {
                const WrappedImage = function(width, height) {
                    const image = arguments.length
                        ? new NativeImage(width, height)
                        : new NativeImage();
                    return image;
                };
                WrappedImage.prototype = NativeImage.prototype;
                Object.setPrototypeOf(WrappedImage, NativeImage);
                window.Image = WrappedImage;
            } catch (e) {
                console.warn('[BandwidthHero] Image() hook failed:', e);
            }
        }
    }

    /* =========================
       DOM rewriter
       ========================= */

    function proxyImage(image) {
        if (!(image instanceof HTMLImageElement)) return;

        for (const attr of IMAGE_ATTRIBUTES) {
            const value = image.getAttribute(attr);
            if (!value) continue;
            const rewritten = rewriteAttributeValue(attr, value);
            if (rewritten !== value) {
                setOriginal(image, value);
                safeSetAttribute(image, attr, rewritten);
            }
        }
    }

    function proxySource(source) {
        if (!(source instanceof HTMLSourceElement) || !INTERCEPT_PICTURE_SOURCES) return;

        for (const attr of SOURCE_ATTRIBUTES) {
            const value = source.getAttribute(attr);
            if (!value) continue;
            const rewritten = rewriteAttributeValue(attr, value);
            if (rewritten !== value) {
                setOriginal(source, value);
                safeSetAttribute(source, attr, rewritten);
            }
        }
    }

    function proxyInputImage(input) {
        if (!(input instanceof HTMLInputElement) || input.type !== 'image') return;
        const value = input.getAttribute('src');
        if (!value) return;
        const proxy = getProxyURL(value);
        if (proxy && proxy !== value) {
            setOriginal(input, value);
            safeSetAttribute(input, 'src', proxy);
        }
    }

    function proxyInlineBackground(element) {
        if (!(element instanceof HTMLElement)) return;
        const style = element.getAttribute('style');
        if (!style || !/background(?:-image)?\s*:/i.test(style)) return;
        const rewritten = rewriteCSSURLs(style);
        if (rewritten !== style) safeSetAttribute(element, 'style', rewritten);
    }

    function isCSPMeta(element) {
        if (!(element instanceof HTMLMetaElement)) return false;
        const httpEquiv = (element.getAttribute('http-equiv') || '').toLowerCase();
        const name = (element.getAttribute('name') || '').toLowerCase();
        return httpEquiv === 'content-security-policy' || name === 'content-security-policy';
    }

    function stripCSPMeta(root = document) {
        if (!STRIP_META_CSP || !root) return;
        if (isCSPMeta(root)) {
            root.remove();
            return;
        }
        if (!root.querySelectorAll) return;
        for (const meta of root.querySelectorAll('meta[http-equiv],meta[name]')) {
            if (isCSPMeta(meta)) meta.remove();
        }
    }

    function processElement(element) {
        if (!(element instanceof Element)) return;

        if (isCSPMeta(element)) {
            element.remove();
            return;
        }

        if (element instanceof HTMLLinkElement) rewritePreload(element);
        if (element instanceof HTMLImageElement) proxyImage(element);
        if (element instanceof HTMLSourceElement) proxySource(element);
        if (element instanceof HTMLInputElement) proxyInputImage(element);
        if (element instanceof HTMLElement) proxyInlineBackground(element);

        // Descendant scans are limited to relevant tags; no getComputedStyle pass.
        for (const image of element.querySelectorAll('img')) proxyImage(image);
        if (INTERCEPT_PICTURE_SOURCES) {
            for (const source of element.querySelectorAll('picture > source, source')) proxySource(source);
        }
        for (const input of element.querySelectorAll('input[type="image"]')) proxyInputImage(input);
        for (const styled of element.querySelectorAll('[style]')) proxyInlineBackground(styled);
        if (INTERCEPT_IMAGE_PRELOADS) {
            for (const link of element.querySelectorAll('link[rel~="preload"][as="image"]')) rewritePreload(link);
        }
        stripCSPMeta(element);
    }

    function processPage() {
        stripCSPMeta();

        for (const image of document.images) proxyImage(image);
        if (INTERCEPT_PICTURE_SOURCES) {
            for (const source of document.querySelectorAll('source')) proxySource(source);
        }
        for (const input of document.querySelectorAll('input[type="image"]')) proxyInputImage(input);
        for (const styled of document.querySelectorAll('[style]')) proxyInlineBackground(styled);
        if (INTERCEPT_IMAGE_PRELOADS) {
            for (const link of document.querySelectorAll('link[rel~="preload"][as="image"]')) rewritePreload(link);
        }
    }

    /* =========================
       Mutation batching
       ========================= */

    const pending = new Set();
    let timer = 0;

    function scheduleElement(element) {
        if (!(element instanceof Element)) return;
        pending.add(element);
        if (timer) return;

        timer = setTimeout(() => {
            timer = 0;
            const batch = Array.from(pending);
            pending.clear();
            for (const element of batch) {
                if (element.isConnected) processElement(element);
            }
        }, 32);
    }

    function startObserver() {
        const observer = new MutationObserver(mutations => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    for (const node of mutation.addedNodes) {
                        if (node instanceof Element) scheduleElement(node);
                    }
                } else if (mutation.type === 'attributes') {
                    const target = mutation.target;
                    if (mutation.attributeName === 'http-equiv' && isCSPMeta(target)) {
                        target.remove();
                    } else {
                        scheduleElement(target);
                    }
                }
            }
        });

        observer.observe(document.documentElement || document, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: OBSERVED_ATTRIBUTES
        });
    }

    /* =========================
       Startup
       ========================= */

    function start() {
        installPrehook();
        stripCSPMeta();
        startObserver();
        processPage();

        // Frameworks/lazy loaders often populate images after initial parsing.
        setTimeout(processPage, 800);
        setTimeout(processPage, 2500);
        setTimeout(processPage, 6000);
    }

    start();
})();
