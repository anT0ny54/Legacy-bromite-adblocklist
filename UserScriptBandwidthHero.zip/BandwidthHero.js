// ==UserScript==
// @name         Bandwidth Hero Proxy
// @namespace    local.bandwidth.hero.userscript
// @version      2.0.0
// @description  Compress page images through a Bandwidth Hero-compatible proxy with caching, lazy-load support, and efficient DOM observation.
// @author       antonyitunamaku
//
// Allowed domains
// @match        https://example.com/*
// @match        https://www.example.com/*
// @match        https://sub.example.org/*
// @match        https://another-domain.net/*
//
// Blacklisted domains
// Replace these examples with the domains where the script must not run.
//
// Exact domain
// @exclude      https://blocked.example/*
//
// All subdomains of a domain
// @exclude      https://*.blocked.example/*
//
// Additional blacklisted domains
// @exclude      https://ads.example.com/*
// @exclude      https://tracking.example.net/*
// @exclude      https://*.social.example.org/*
//
// Script settings
// @run-at       document-start
// @noframes
// @grant        none
// ==/UserScript==

(() => {
  "use strict";

  const PROXY_URL = "https://your-netlify-domain.netlify.app/api/index";

  const SETTINGS = Object.freeze({
    quality: 40,
    maxWidth: 1280,
    jpeg: false,
    grayscale: false,

    minimumWidth: 100,
    minimumHeight: 100,
    minimumImageDimensions: true,

    processSvg: false,
    processBackgroundImages: true,
    processLazyAttributes: true,

    idleTimeout: 500,
    maxCacheSize: 1500
  });

  const ATTR = Object.freeze({
    originalSrc: "data-bh-orig-src",
    originalSrcset: "data-bh-orig-srcset",
    originalDataSrc: "data-bh-orig-dsrc",
    originalLazySrc: "data-bh-orig-lsrc",
    originalDataSrcset: "data-bh-orig-dsrcset",
    originalStyle: "data-bh-orig-style",
    processed: "data-bh-proc"
  });

  const REGEX = Object.freeze({
    httpUrl: /^https?:\/\//i,
    svgFile: /\.svg(?:$|[?#])/i,
    dataUrl: /^data:/i,
    hashUrl: /^#/,
    cssUrl: /url\s*\(\s*(["']?)(.*?)\1\s*\)/gi,
    urlFunction: /url\s*\(/i,
    srcsetSplit: /\s*,\s*/,
    srcsetParts: /\s+/
  });

  class LRUCache {
    constructor(maxSize) {
      this.maxSize = Math.max(1, maxSize);
      this.map = new Map();
    }

    get(key) {
      if (!this.map.has(key)) {
        return undefined;
      }

      const value = this.map.get(key);

      this.map.delete(key);
      this.map.set(key, value);

      return value;
    }

    set(key, value) {
      if (this.map.has(key)) {
        this.map.delete(key);
      } else if (this.map.size >= this.maxSize) {
        const oldestKey = this.map.keys().next().value;
        this.map.delete(oldestKey);
      }

      this.map.set(key, value);
    }
  }

  let proxy;
  let proxyPrefix;

  try {
    proxy = new URL(PROXY_URL);

    if (
      !REGEX.httpUrl.test(proxy.href) ||
      proxy.hostname.includes("YOUR-PROXY-DOMAIN")
    ) {
      throw new Error("Invalid proxy URL");
    }

    const params = new URLSearchParams({
      quality: String(SETTINGS.quality),
      jpeg: SETTINGS.jpeg ? "1" : "0",
      bw: SETTINGS.grayscale ? "1" : "0"
    });

    if (SETTINGS.maxWidth > 0) {
      params.set("max_width", String(SETTINGS.maxWidth));
    }

    proxyPrefix =
      `${proxy.origin}${proxy.pathname}?${params.toString()}&url=`;
  } catch {
    console.warn(
      "[Bandwidth Hero] Configure a valid PROXY_URL in the userscript."
    );
    return;
  }

  const absoluteUrlCache = new LRUCache(SETTINGS.maxCacheSize);
  const proxyUrlCache = new LRUCache(SETTINGS.maxCacheSize);
  const skipUrlCache = new LRUCache(SETTINGS.maxCacheSize);

  const processedValues = new WeakMap();

  function getAbsoluteUrl(value) {
    if (typeof value !== "string") {
      return "";
    }

    const normalizedValue = value.trim();

    if (!normalizedValue) {
      return "";
    }

    const cached = absoluteUrlCache.get(normalizedValue);

    if (cached !== undefined) {
      return cached;
    }

    try {
      const absoluteUrl = new URL(
        normalizedValue,
        document.baseURI || location.href
      ).href;

      absoluteUrlCache.set(normalizedValue, absoluteUrl);
      return absoluteUrl;
    } catch {
      absoluteUrlCache.set(normalizedValue, "");
      return "";
    }
  }

  function isProxyUrl(value) {
    try {
      const url = new URL(value);

      return (
        url.origin === proxy.origin &&
        url.pathname === proxy.pathname
      );
    } catch {
      return false;
    }
  }

  function shouldSkipUrl(value) {
    if (typeof value !== "string") {
      return true;
    }

    const normalizedValue = value.trim();

    if (!normalizedValue) {
      return true;
    }

    const cached = skipUrlCache.get(normalizedValue);

    if (cached !== undefined) {
      return cached;
    }

    const absoluteUrl = getAbsoluteUrl(normalizedValue);
    let skip = true;

    if (absoluteUrl && REGEX.httpUrl.test(absoluteUrl)) {
      if (isProxyUrl(absoluteUrl)) {
        skip = true;
      } else {
        skip =
          !SETTINGS.processSvg &&
          REGEX.svgFile.test(absoluteUrl);
      }
    }

    skipUrlCache.set(normalizedValue, skip);
    return skip;
  }

  function createProxyUrl(value) {
    if (typeof value !== "string") {
      return value;
    }

    const normalizedValue = value.trim();

    if (!normalizedValue) {
      return value;
    }

    const absoluteUrl = getAbsoluteUrl(normalizedValue);

    if (!absoluteUrl || shouldSkipUrl(absoluteUrl)) {
      return value;
    }

    const cached = proxyUrlCache.get(absoluteUrl);

    if (cached !== undefined) {
      return cached;
    }

    const proxiedUrl =
      proxyPrefix + encodeURIComponent(absoluteUrl);

    proxyUrlCache.set(absoluteUrl, proxiedUrl);

    return proxiedUrl;
  }

  function setAttributeIfChanged(element, name, value) {
    if (
      value == null ||
      element.getAttribute(name) === value
    ) {
      return false;
    }

    element.setAttribute(name, value);
    return true;
  }

  function saveOriginalAttribute(element, name, value) {
    if (
      value == null ||
      element.hasAttribute(name)
    ) {
      return;
    }

    element.setAttribute(name, value);
  }

  function wasAlreadyProcessed(element, attributeName, value) {
    let values = processedValues.get(element);

    if (!values) {
      values = new Map();
      processedValues.set(element, values);
    }

    if (values.get(attributeName) === value) {
      return true;
    }

    values.set(attributeName, value);
    return false;
  }

  function rewriteSrcset(srcset) {
    if (
      typeof srcset !== "string" ||
      !srcset.trim()
    ) {
      return srcset;
    }

    const candidates = srcset.split(REGEX.srcsetSplit);
    let changed = false;

    const rewritten = candidates.map(candidate => {
      const trimmedCandidate = candidate.trim();

      if (!trimmedCandidate) {
        return candidate;
      }

      const parts = trimmedCandidate.split(REGEX.srcsetParts);
      const sourceUrl = parts.shift();

      if (!sourceUrl) {
        return candidate;
      }

      const proxiedUrl = createProxyUrl(sourceUrl);

      if (proxiedUrl === sourceUrl) {
        return candidate;
      }

      parts.unshift(proxiedUrl);
      changed = true;

      return parts.join(" ");
    });

    return changed
      ? rewritten.join(", ")
      : srcset;
  }

  function isLargeEnough(image) {
    if (!SETTINGS.minimumImageDimensions) {
      return true;
    }

    const width =
      image.naturalWidth ||
      Number.parseInt(image.getAttribute("width"), 10) ||
      image.clientWidth ||
      0;

    const height =
      image.naturalHeight ||
      Number.parseInt(image.getAttribute("height"), 10) ||
      image.clientHeight ||
      0;

    if (!width && !height) {
      return true;
    }

    return (
      width >= SETTINGS.minimumWidth &&
      height >= SETTINGS.minimumHeight
    );
  }

  function processUrlAttribute(
    element,
    attributeName,
    originalAttributeName
  ) {
    const value = element.getAttribute(attributeName);

    if (!value) {
      return false;
    }

    if (
      wasAlreadyProcessed(
        element,
        attributeName,
        value
      )
    ) {
      return false;
    }

    const proxiedUrl = createProxyUrl(value);

    if (proxiedUrl === value) {
      return false;
    }

    saveOriginalAttribute(
      element,
      originalAttributeName,
      value
    );

    return setAttributeIfChanged(
      element,
      attributeName,
      proxiedUrl
    );
  }

  function processSrcsetAttribute(
    element,
    attributeName,
    originalAttributeName
  ) {
    const value = element.getAttribute(attributeName);

    if (!value) {
      return false;
    }

    if (
      wasAlreadyProcessed(
        element,
        attributeName,
        value
      )
    ) {
      return false;
    }

    const rewritten = rewriteSrcset(value);

    if (rewritten === value) {
      return false;
    }

    saveOriginalAttribute(
      element,
      originalAttributeName,
      value
    );

    return setAttributeIfChanged(
      element,
      attributeName,
      rewritten
    );
  }

  function processImage(image) {
    if (!(image instanceof HTMLImageElement)) {
      return;
    }

    if (!isLargeEnough(image)) {
      return;
    }

    let changed = false;

    changed =
      processUrlAttribute(
        image,
        "src",
        ATTR.originalSrc
      ) || changed;

    changed =
      processSrcsetAttribute(
        image,
        "srcset",
        ATTR.originalSrcset
      ) || changed;

    if (SETTINGS.processLazyAttributes) {
      changed =
        processUrlAttribute(
          image,
          "data-src",
          ATTR.originalDataSrc
        ) || changed;

      changed =
        processUrlAttribute(
          image,
          "data-lazy-src",
          ATTR.originalLazySrc
        ) || changed;

      changed =
        processSrcsetAttribute(
          image,
          "data-srcset",
          ATTR.originalDataSrcset
        ) || changed;
    }

    if (changed) {
      image.setAttribute(ATTR.processed, "true");
    }
  }

  function processSource(source) {
    if (!(source instanceof HTMLSourceElement)) {
      return;
    }

    let changed = false;

    changed =
      processSrcsetAttribute(
        source,
        "srcset",
        ATTR.originalSrcset
      ) || changed;

    if (SETTINGS.processLazyAttributes) {
      changed =
        processSrcsetAttribute(
          source,
          "data-srcset",
          ATTR.originalDataSrcset
        ) || changed;
    }

    if (changed) {
      source.setAttribute(ATTR.processed, "true");
    }
  }

  function processBackgroundImage(element) {
    if (
      !SETTINGS.processBackgroundImages ||
      !(element instanceof HTMLElement)
    ) {
      return;
    }

    const style = element.getAttribute("style");

    if (
      !style ||
      !REGEX.urlFunction.test(style)
    ) {
      return;
    }

    if (
      wasAlreadyProcessed(
        element,
        "style",
        style
      )
    ) {
      return;
    }

    let changed = false;

    const rewritten = style.replace(
      REGEX.cssUrl,
      (match, quote, rawUrl) => {
        const value = rawUrl.trim();

        if (
          !value ||
          REGEX.dataUrl.test(value) ||
          REGEX.hashUrl.test(value)
        ) {
          return match;
        }

        const proxiedUrl = createProxyUrl(value);

        if (proxiedUrl === value) {
          return match;
        }

        changed = true;
        return `url("${proxiedUrl}")`;
      }
    );

    if (!changed) {
      return;
    }

    saveOriginalAttribute(
      element,
      ATTR.originalStyle,
      style
    );

    setAttributeIfChanged(
      element,
      "style",
      rewritten
    );

    element.setAttribute(ATTR.processed, "true");
  }

  function processElement(element) {
    if (!(element instanceof Element)) {
      return;
    }

    switch (element.tagName) {
      case "IMG":
        processImage(element);
        break;

      case "SOURCE":
        processSource(element);
        break;
    }

    if (SETTINGS.processBackgroundImages) {
      processBackgroundImage(element);
    }
  }

  function processSubtree(root) {
    if (!(root instanceof Element)) {
      return;
    }

    processElement(root);

    const elements = root.querySelectorAll(
      "img, source, [style]"
    );

    for (const element of elements) {
      processElement(element);
    }
  }

  const pendingRoots = new Set();
  let processingScheduled = false;

  function processPendingRoots(deadline) {
    processingScheduled = false;

    const roots = Array.from(pendingRoots);

    for (const root of roots) {
      if (
        !deadline.didTimeout &&
        deadline.timeRemaining() <= 1
      ) {
        break;
      }

      pendingRoots.delete(root);

      if (
        root.isConnected ||
        root === document.documentElement
      ) {
        processSubtree(root);
      }
    }

    if (pendingRoots.size) {
      scheduleProcessing();
    }
  }

  function scheduleProcessing() {
    if (processingScheduled) {
      return;
    }

    processingScheduled = true;

    if (
      typeof window.requestIdleCallback === "function"
    ) {
      window.requestIdleCallback(
        processPendingRoots,
        {
          timeout: SETTINGS.idleTimeout
        }
      );
    } else {
      window.setTimeout(() => {
        processPendingRoots({
          didTimeout: true,
          timeRemaining: () => 50
        });
      }, 0);
    }
  }

  function enqueue(root) {
    if (!(root instanceof Element)) {
      return;
    }

    const documentRoot = document.documentElement;

    if (
      root !== documentRoot &&
      pendingRoots.has(documentRoot)
    ) {
      return;
    }

    let parent = root.parentElement;

    while (parent) {
      if (pendingRoots.has(parent)) {
        return;
      }

      parent = parent.parentElement;
    }

    for (const pendingRoot of pendingRoots) {
      if (
        pendingRoot !== root &&
        root.contains(pendingRoot)
      ) {
        pendingRoots.delete(pendingRoot);
      }
    }

    pendingRoots.add(root);
    scheduleProcessing();
  }

  const observedAttributes = [
    "src",
    "srcset",
    "style"
  ];

  if (SETTINGS.processLazyAttributes) {
    observedAttributes.push(
      "data-src",
      "data-lazy-src",
      "data-srcset"
    );
  }

  const observer = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      if (mutation.type === "childList") {
        for (const node of mutation.addedNodes) {
          if (node instanceof Element) {
            enqueue(node);
          }
        }
      } else if (mutation.type === "attributes") {
        enqueue(mutation.target);
      }
    }
  });

  function initialize() {
    const root = document.documentElement;

    if (!root) {
      return;
    }

    enqueue(root);

    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: observedAttributes
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      initialize,
      { once: true }
    );
  } else {
    initialize();
  }
})();
