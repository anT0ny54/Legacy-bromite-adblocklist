// ==UserScript==
// @name         Bandwidth Hero Proxy
// @namespace    local.bandwidth.hero.userscript
// @version      2.1.0
// @description  Compress page images through a Bandwidth Hero-compatible proxy with caching, lazy-load support, and efficient DOM observation.
// @author       antonyitunamaku
//
// Allowed domains
// @match        https://example.com/*
// @match        https://www.example.com/*
// @match        https://sub.example.org/*
// @match        https://another-domain.net/*
//
// Blacklisted domains
// Replace these examples with the domains where the script must not run.
//
// Exact domain
// @exclude      https://blocked.example/*
//
// All subdomains of a domain
// @exclude      https://*.blocked.example/*
//
// Additional blacklisted domains
// @exclude      https://ads.example.com/*
// @exclude      https://tracking.example.net/*
// @exclude      https://*.social.example.org/*
//
// Script settings
// @run-at       document-start
// @noframes
// @grant        none
// ==/UserScript==

(() => {
  "use strict";

  /*
   * Configure your deployed Bandwidth Hero-compatible endpoints here.
   * They should accept:
   *   ?url=IMAGE_URL&quality=40&jpeg=0&bw=0&max_width=1280
   */
  const PROXY_ENDPOINTS = Object.freeze([
    "https://your-netlify-domain.netlify.app/api/index",
    "https://your-netlify-domain2.netlify.app/api/index"
  ]);

  const SETTINGS = Object.freeze({
    quality: 40,
    maxWidth: 1280,
    jpeg: false,
    grayscale: false,

    minimumWidth: 100,
    minimumHeight: 100,
    minimumImageDimensions: true,

    processSvg: false,
    processBackgroundImages: true,
    processLazyAttributes: true,

    idleTimeout: 500,
    maxCacheSize: 1500,

    // Endpoint reachability checks are deliberately lightweight.
    healthCheckTimeout: 2500,
    healthCheckCooldown: 30000,

    // If a proxied image itself fails, try another endpoint once.
    enableImageFailover: true,
    failoverTimeout: 8000
  });

  const ATTR = Object.freeze({
    originalSrc: "data-bh-original-src",
    originalSrcset: "data-bh-original-srcset",
    originalDataSrc: "data-bh-original-data-src",
    originalLazySrc: "data-bh-original-lazy-src",
    originalDataSrcset: "data-bh-original-data-srcset",
    originalStyle: "data-bh-original-style",
    processed: "data-bh-processed",
    failoverTried: "data-bh-failover-tried"
  });

  const REGEX = Object.freeze({
    httpUrl: /^https?:\/\//i,
    svgFile: /\.svg(?:$|[?#])/i,
    dataUrl: /^data:/i,
    hashUrl: /^#/,
    cssUrl: /url\s*\(\s*(["']?)(.*?)\1\s*\)/gi,
    urlFunction: /url\s*\(/i,
    srcsetSplit: /\s*,\s*/,
    srcsetParts: /\s+/,
    proxyUrl: /^https?:\/\//i
  });

  class LRUCache {
    constructor(maxSize) {
      this.maxSize = Math.max(1, maxSize);
      this.map = new Map();
    }

    get(key) {
      if (!this.map.has(key)) return undefined;
      const value = this.map.get(key);
      this.map.delete(key);
      this.map.set(key, value);
      return value;
    }

    set(key, value) {
      if (this.map.has(key)) this.map.delete(key);
      else if (this.map.size >= this.maxSize) {
        const oldestKey = this.map.keys().next().value;
        this.map.delete(oldestKey);
      }
      this.map.set(key, value);
    }

    delete(key) {
      this.map.delete(key);
    }

    clear() {
      this.map.clear();
    }
  }

  const absoluteUrlCache = new LRUCache(SETTINGS.maxCacheSize);
  const proxyUrlCache = new LRUCache(SETTINGS.maxCacheSize);
  const skipUrlCache = new LRUCache(SETTINGS.maxCacheSize);
  const processedValues = new WeakMap();

  let proxyServers;

  try {
    proxyServers = PROXY_ENDPOINTS
      .map(endpoint => new URL(endpoint))
      .filter(url => {
        return (
          /^https?:$/i.test(url.protocol) &&
          Boolean(url.hostname) &&
          !url.hostname.includes("YOUR-PROXY-DOMAIN") &&
          !url.hostname.includes("your-project")
        );
      });

    if (!proxyServers.length) {
      throw new Error("No valid proxy endpoints configured");
    }
  } catch {
    console.warn(
      "[Bandwidth Hero] Configure valid Vercel or Netlify proxy endpoints."
    );
    return;
  }

  /*
   * Health state:
   *   healthy = true/false/null (null = unknown)
   *   lastCheck = timestamp
   *   pending = shared promise while a check is running
   */
  const proxyHealth = new Map();

  function proxyKey(proxy) {
    return proxy.origin + proxy.pathname;
  }

  function getHealthRecord(proxy) {
    const key = proxyKey(proxy);
    let record = proxyHealth.get(key);

    if (!record) {
      record = { healthy: null, lastCheck: 0, pending: null };
      proxyHealth.set(key, record);
    }

    return record;
  }

  function isHealthFresh(record) {
    return (
      record &&
      record.lastCheck > 0 &&
      Date.now() - record.lastCheck < SETTINGS.healthCheckCooldown
    );
  }

  async function healthCheckProxy(proxy) {
    const key = proxyKey(proxy);
    const record = getHealthRecord(proxy);

    if (record.pending) return record.pending;
    if (isHealthFresh(record)) return record.healthy;

    const pending = (async () => {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), SETTINGS.healthCheckTimeout);

      try {
        /*
         * no-cors is intentional: a cross-origin endpoint does not need to
         * expose CORS headers merely for this reachability probe. Opaque
         * responses are still useful here; fetch rejection means network /
         * connection failure or timeout.
         */
        await fetch(proxy.href, {
          method: "HEAD",
          mode: "no-cors",
          cache: "no-store",
          signal: controller.signal
        });

        record.healthy = true;
      } catch {
        record.healthy = false;
      } finally {
        record.lastCheck = Date.now();
        record.pending = null;
        window.clearTimeout(timer);
      }

      // A health transition can invalidate cached endpoint choices.
      proxyUrlCache.clear();
      return record.healthy;
    })();

    record.pending = pending;
    return pending;
  }

  function hashString(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function getAbsoluteUrl(value) {
    if (typeof value !== "string") return "";
    const normalizedValue = value.trim();
    if (!normalizedValue) return "";

    const cached = absoluteUrlCache.get(normalizedValue);
    if (cached !== undefined) return cached;

    try {
      const absoluteUrl = new URL(
        normalizedValue,
        document.baseURI || location.href
      ).href;
      absoluteUrlCache.set(normalizedValue, absoluteUrl);
      return absoluteUrl;
    } catch {
      absoluteUrlCache.set(normalizedValue, "");
      return "";
    }
  }

  function isProxyUrl(value) {
    try {
      const url = new URL(value);
      return proxyServers.some(proxy => (
        url.origin === proxy.origin &&
        url.pathname === proxy.pathname
      ));
    } catch {
      return false;
    }
  }

  function shouldSkipUrl(value) {
    if (typeof value !== "string") return true;

    const normalizedValue = value.trim();
    if (!normalizedValue) return true;

    const cached = skipUrlCache.get(normalizedValue);
    if (cached !== undefined) return cached;

    const absoluteUrl = getAbsoluteUrl(normalizedValue);
    let skip = true;

    if (absoluteUrl && REGEX.httpUrl.test(absoluteUrl)) {
      if (isProxyUrl(absoluteUrl)) {
        skip = true;
      } else {
        skip = !SETTINGS.processSvg && REGEX.svgFile.test(absoluteUrl);
      }
    }

    skipUrlCache.set(normalizedValue, skip);
    return skip;
  }

  function getProxyCandidates(imageUrl) {
    let preferredIndex = 0;

    try {
      const hostname = new URL(imageUrl).hostname;
      preferredIndex = hashString(hostname) % proxyServers.length;
    } catch {
      // Keep the first endpoint as the deterministic fallback.
    }

    const ordered = [];
    for (let i = 0; i < proxyServers.length; i++) {
      ordered.push(proxyServers[(preferredIndex + i) % proxyServers.length]);
    }

    return ordered;
  }

  async function pickHealthyProxyServer(imageUrl, excludedKeys = new Set()) {
    const candidates = getProxyCandidates(imageUrl);

    // First prefer a known-healthy endpoint.
    for (const proxy of candidates) {
      const key = proxyKey(proxy);
      if (excludedKeys.has(key)) continue;

      const record = getHealthRecord(proxy);
      if (isHealthFresh(record) && record.healthy === true) {
        return proxy;
      }
    }

    // Then actively probe candidates in deterministic order.
    for (const proxy of candidates) {
      const key = proxyKey(proxy);
      if (excludedKeys.has(key)) continue;

      if (await healthCheckProxy(proxy)) return proxy;
    }

    // Last resort: don't disable image processing just because every probe
    // failed. The actual image request may still succeed.
    return candidates.find(proxy => !excludedKeys.has(proxyKey(proxy))) || candidates[0];
  }

  function buildProxyUrl(imageUrl, endpoint) {
    const proxyUrl = new URL(endpoint.href);

    proxyUrl.searchParams.set("quality", String(SETTINGS.quality));
    proxyUrl.searchParams.set("jpeg", SETTINGS.jpeg ? "1" : "0");
    proxyUrl.searchParams.set("bw", SETTINGS.grayscale ? "1" : "0");

    if (SETTINGS.maxWidth > 0) {
      proxyUrl.searchParams.set("max_width", String(SETTINGS.maxWidth));
    }

    proxyUrl.searchParams.set("url", imageUrl);
    return proxyUrl.href;
  }

  async function createProxyUrl(value, options = {}) {
    if (typeof value !== "string") return value;

    const normalizedValue = value.trim();
    if (!normalizedValue) return value;

    const absoluteUrl = getAbsoluteUrl(normalizedValue);
    if (!absoluteUrl || shouldSkipUrl(absoluteUrl)) return value;

    const excludedKeys = options.excludedKeys || new Set();
    const cacheKey = excludedKeys.size === 0 ? absoluteUrl : null;

    if (cacheKey) {
      const cached = proxyUrlCache.get(cacheKey);
      if (cached !== undefined) return cached;
    }

    const endpoint = await pickHealthyProxyServer(absoluteUrl, excludedKeys);
    const proxiedUrl = buildProxyUrl(absoluteUrl, endpoint);

    if (cacheKey) proxyUrlCache.set(cacheKey, proxiedUrl);
    return proxiedUrl;
  }

  function setAttributeIfChanged(element, name, value) {
    if (value == null || element.getAttribute(name) === value) return false;
    element.setAttribute(name, value);
    return true;
  }

  function saveOriginalAttribute(element, name, value) {
    if (value == null || element.hasAttribute(name)) return;
    element.setAttribute(name, value);
  }

  function wasAlreadyProcessed(element, attributeName, value) {
    let values = processedValues.get(element);

    if (!values) {
      values = new Map();
      processedValues.set(element, values);
    }

    if (values.get(attributeName) === value) return true;
    values.set(attributeName, value);
    return false;
  }

  async function rewriteSrcsetAsync(srcset) {
    if (typeof srcset !== "string" || !srcset.trim()) return srcset;

    const candidates = srcset.split(REGEX.srcsetSplit);
    let changed = false;
    const mapped = [];

    for (const candidate of candidates) {
      const trimmedCandidate = candidate.trim();
      if (!trimmedCandidate) {
        mapped.push(candidate);
        continue;
      }

      const parts = trimmedCandidate.split(REGEX.srcsetParts);
      const sourceUrl = parts.shift();
      if (!sourceUrl) {
        mapped.push(candidate);
        continue;
      }

      const proxiedUrl = await createProxyUrl(sourceUrl);
      if (proxiedUrl === sourceUrl) {
        mapped.push(candidate);
        continue;
      }

      parts.unshift(proxiedUrl);
      changed = true;
      mapped.push(parts.join(" "));
    }

    return changed ? mapped.join(", ") : srcset;
  }

  async function processUrlAttribute(element, attributeName, originalAttributeName) {
    const value = element.getAttribute(attributeName);
    if (!value) return false;
    if (wasAlreadyProcessed(element, attributeName, value)) return false;

    const proxiedUrl = await createProxyUrl(value);
    if (proxiedUrl === value) return false;

    saveOriginalAttribute(element, originalAttributeName, value);
    return setAttributeIfChanged(element, attributeName, proxiedUrl);
  }

  async function processSrcsetAttribute(element, attributeName, originalAttributeName) {
    const value = element.getAttribute(attributeName);
    if (!value) return false;
    if (wasAlreadyProcessed(element, attributeName, value)) return false;

    const rewritten = await rewriteSrcsetAsync(value);
    if (rewritten === value) return false;

    saveOriginalAttribute(element, originalAttributeName, value);
    return setAttributeIfChanged(element, attributeName, rewritten);
  }

  function isLargeEnough(image) {
    if (!SETTINGS.minimumImageDimensions) return true;

    const width =
      image.naturalWidth ||
      Number.parseInt(image.getAttribute("width"), 10) ||
      image.clientWidth ||
      0;

    const height =
      image.naturalHeight ||
      Number.parseInt(image.getAttribute("height"), 10) ||
      image.clientHeight ||
      0;

    // Unknown dimensions are processed so lazy/dynamically loaded images
    // are not accidentally skipped.
    if (!width && !height) return true;

    return width >= SETTINGS.minimumWidth && height >= SETTINGS.minimumHeight;
  }

  async function processImage(image) {
    if (!(image instanceof HTMLImageElement)) return;
    if (!isLargeEnough(image)) return;

    let changed = false;

    changed = await processUrlAttribute(image, "src", ATTR.originalSrc) || changed;
    changed = await processSrcsetAttribute(image, "srcset", ATTR.originalSrcset) || changed;

    if (SETTINGS.processLazyAttributes) {
      changed = await processUrlAttribute(image, "data-src", ATTR.originalDataSrc) || changed;
      changed = await processUrlAttribute(image, "data-lazy-src", ATTR.originalLazySrc) || changed;
      changed = await processSrcsetAttribute(image, "data-srcset", ATTR.originalDataSrcset) || changed;
    }

    if (changed) {
      image.setAttribute(ATTR.processed, "true");
      installImageFailover(image);
    }
  }

  async function processSource(source) {
    if (!(source instanceof HTMLSourceElement)) return;

    let changed = false;
    changed = await processSrcsetAttribute(source, "srcset", ATTR.originalSrcset) || changed;

    if (SETTINGS.processLazyAttributes) {
      changed = await processSrcsetAttribute(source, "data-srcset", ATTR.originalDataSrcset) || changed;
    }

    if (changed) source.setAttribute(ATTR.processed, "true");
  }

  async function rewriteBackgroundStyle(style) {
    if (!style || !REGEX.urlFunction.test(style)) return style;

    const matches = Array.from(style.matchAll(REGEX.cssUrl));
    if (!matches.length) return style;

    let changed = false;
    let output = "";
    let lastIndex = 0;

    for (const match of matches) {
      output += style.slice(lastIndex, match.index);
      const rawUrl = match[2].trim();

      if (
        !rawUrl ||
        REGEX.dataUrl.test(rawUrl) ||
        REGEX.hashUrl.test(rawUrl)
      ) {
        output += match[0];
      } else {
        const proxiedUrl = await createProxyUrl(rawUrl);
        if (proxiedUrl === rawUrl) {
          output += match[0];
        } else {
          output += `url("${proxiedUrl}")`;
          changed = true;
        }
      }

      lastIndex = match.index + match[0].length;
    }

    output += style.slice(lastIndex);
    return changed ? output : style;
  }

  async function processBackgroundImage(element) {
    if (!SETTINGS.processBackgroundImages) return;
    if (!(element instanceof HTMLElement)) return;

    const style = element.getAttribute("style");
    if (!style || !REGEX.urlFunction.test(style)) return;
    if (wasAlreadyProcessed(element, "style", style)) return;

    const rewritten = await rewriteBackgroundStyle(style);
    if (rewritten === style) return;

    saveOriginalAttribute(element, ATTR.originalStyle, style);
    setAttributeIfChanged(element, "style", rewritten);
    element.setAttribute(ATTR.processed, "true");
  }

  async function processElement(element) {
    if (!(element instanceof Element)) return;

    switch (element.tagName) {
      case "IMG":
        await processImage(element);
        break;
      case "SOURCE":
        await processSource(element);
        break;
    }

    if (SETTINGS.processBackgroundImages) {
      await processBackgroundImage(element);
    }
  }

  async function processSubtree(root) {
    if (!(root instanceof Element)) return;

    await processElement(root);

    const elements = root.querySelectorAll("img, source, [style]");
    for (const element of elements) {
      await processElement(element);
    }
  }

  /*
   * Per-image failover. Endpoint health checks can only tell us that the
   * deployment is reachable; the actual image request can still fail due to
   * an upstream image host, proxy runtime error, or bad response.
   */
  function installImageFailover(image) {
    if (!SETTINGS.enableImageFailover) return;
    if (image.hasAttribute(ATTR.failoverTried)) return;

    const originalSrc = image.getAttribute(ATTR.originalSrc);
    if (!originalSrc) return;

    const initialSrc = image.getAttribute("src");
    if (!initialSrc || initialSrc === originalSrc) return;

    const onError = async () => {
      if (image.getAttribute("src") !== initialSrc) return;

      image.setAttribute(ATTR.failoverTried, "true");
      image.removeEventListener("error", onError);

      try {
        const failedProxy = new URL(initialSrc);
        const excludedKeys = new Set();

        for (const proxy of proxyServers) {
          if (
            proxy.origin === failedProxy.origin &&
            proxy.pathname === failedProxy.pathname
          ) {
            excludedKeys.add(proxyKey(proxy));
            const record = getHealthRecord(proxy);
            record.healthy = false;
            record.lastCheck = Date.now();
            record.pending = null;
          }
        }

        proxyUrlCache.delete(getAbsoluteUrl(originalSrc));

        const replacement = await createProxyUrl(originalSrc, { excludedKeys });

        if (replacement === originalSrc || replacement === initialSrc) {
          setAttributeIfChanged(image, "src", originalSrc);
          return;
        }

        /*
         * Only retry once. If the replacement also fails, restore the real
         * source instead of cycling endlessly between two broken proxies.
         */
        const restoreOnError = () => {
          image.removeEventListener("error", restoreOnError);
          setAttributeIfChanged(image, "src", originalSrc);
        };

        image.addEventListener("error", restoreOnError, { once: true });
        image.removeAttribute(ATTR.failoverTried);
        image.setAttribute("src", replacement);
      } catch {
        setAttributeIfChanged(image, "src", originalSrc);
      }
    };

    image.addEventListener("error", onError);
  }

  const pendingRoots = new Set();
  let processingScheduled = false;

  async function processPendingRoots(deadline) {
    processingScheduled = false;
    const roots = Array.from(pendingRoots);

    for (const root of roots) {
      if (!deadline.didTimeout && deadline.timeRemaining() <= 1) break;

      pendingRoots.delete(root);
      if (root.isConnected || root === document.documentElement) {
        await processSubtree(root);
      }
    }

    if (pendingRoots.size) scheduleProcessing();
  }

  function scheduleProcessing() {
    if (processingScheduled) return;
    processingScheduled = true;

    if (typeof window.requestIdleCallback === "function") {
      window.requestIdleCallback(processPendingRoots, {
        timeout: SETTINGS.idleTimeout
      });
    } else {
      window.setTimeout(() => {
        processPendingRoots({
          didTimeout: true,
          timeRemaining: () => 50
        });
      }, 0);
    }
  }

  function enqueue(root) {
    if (!(root instanceof Element)) return;

    const documentRoot = document.documentElement;
    if (root !== documentRoot && pendingRoots.has(documentRoot)) return;

    let parent = root.parentElement;
    while (parent) {
      if (pendingRoots.has(parent)) return;
      parent = parent.parentElement;
    }

    for (const pendingRoot of pendingRoots) {
      if (pendingRoot !== root && root.contains(pendingRoot)) {
        pendingRoots.delete(pendingRoot);
      }
    }

    pendingRoots.add(root);
    scheduleProcessing();
  }

  const observedAttributes = ["src", "srcset", "style"];
  if (SETTINGS.processLazyAttributes) {
    observedAttributes.push("data-src", "data-lazy-src", "data-srcset");
  }

  const observer = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      if (mutation.type === "childList") {
        for (const node of mutation.addedNodes) {
          if (node instanceof Element) enqueue(node);
        }
      }

      if (mutation.type === "attributes") {
        enqueue(mutation.target);
      }
    }
  });

  function initialize() {
    const root = document.documentElement;
    if (!root) return;

    enqueue(root);

    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: observedAttributes
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize, { once: true });
  } else {
    initialize();
  }
})();
